package es.iesra.edes.sgc

// Clase BaseDeDatosClientes para gestionar la base de datos
class BaseDeDatosClientes {
    private val clientes = mutableMapOf<String, Cliente>()

    fun agregarCliente(cliente: Cliente): Boolean {
        return if (clientes.containsKey(cliente.nif)) {
            false
        } else {
            clientes[cliente.nif] = cliente
            true
        }
    }

    fun eliminarCliente(nif: String): Boolean {
        return clientes.remove(nif) != null
    }

    fun buscarCliente(nif: String): Cliente? {
        return clientes[nif]
    }

    fun listarTodosLosClientes(): List<Cliente> {
        return clientes.values.toList()
    }

    fun listarClientesPreferentes(): List<Cliente> {
        return clientes.values.filter { it.preferente }
    }
}