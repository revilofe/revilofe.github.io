package es.iesra.edes.sgc

// Clase Cliente
data class Cliente(
    val nif: String,
    var nombre: String,
    var direccion: String,
    var telefono: String,
    var correo: String,
    var preferente: Boolean
)
