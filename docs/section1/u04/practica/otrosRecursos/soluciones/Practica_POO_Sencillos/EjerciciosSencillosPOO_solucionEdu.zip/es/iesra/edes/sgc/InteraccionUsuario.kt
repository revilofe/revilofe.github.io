package es.iesra.edes.sgc

// Clase InteraccionUsuario para manejar la interacción con el usuario
class InteraccionUsuario {

    fun pedirOpcion(): Int {
        mostrarMensaje("\nMenú de opciones:")
        mostrarMensaje("1) Añadir cliente")
        mostrarMensaje("2) Eliminar cliente")
        mostrarMensaje("3) Mostrar cliente")
        mostrarMensaje("4) Listar todos los clientes")
        mostrarMensaje("5) Listar clientes preferentes")
        mostrarMensaje("6) Terminar")
        return solicitarDato("Elige una opción: ").toIntOrNull() ?: -1
    }

    fun solicitarDatosCliente(): Cliente {
        mostrarMensaje("\nIntroduce los datos del cliente:")
        val nif = solicitarDato("NIF: ")
        val nombre = solicitarDato("Nombre: ")
        val direccion = solicitarDato("Dirección: ")
        val telefono = solicitarDato("Teléfono: ")
        val correo = solicitarDato("Correo: ")
        val preferente = solicitarDato("Preferente [true|false]: ").toBoolean()
        return Cliente(nif, nombre, direccion, telefono, correo, preferente)
    }

    fun solicitarDato(mensaje: String): String {
        mostrarMensaje(mensaje)
        var dato: String
        do {
            dato = readln().trim()
        } while (dato.isEmpty())
        return dato
    }

    fun mostrarMensaje(mensaje: String) {
        println(mensaje)
    }

    fun mostrarCliente(cliente: Cliente?) {
        if (cliente != null) {
            mostrarMensaje("\nDatos del cliente:")
            mostrarMensaje(cliente.toString())
        } else {
            mostrarMensaje("No se encontró un cliente con ese NIF.")
        }
    }

    fun mostrarListaClientes(clientes: List<Cliente>, titulo: String = "Lista de clientes") {
        if (clientes.isNotEmpty()) {
            mostrarMensaje("\n$titulo:")
            clientes.forEach { mostrarMensaje("- ${it.nif}: ${it.nombre}") }
        } else {
            mostrarMensaje("No hay clientes en esta lista.")
        }
    }
}