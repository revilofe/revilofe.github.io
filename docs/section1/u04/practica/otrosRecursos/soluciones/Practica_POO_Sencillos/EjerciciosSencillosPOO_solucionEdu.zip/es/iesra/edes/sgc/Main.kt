package es.iesra.edes.sgc

// Función main para ejecutar el programa
fun main() {
    val baseDeDatos = BaseDeDatosClientes()
    val interaccionUsuario = InteraccionUsuario()
    val sistema = SistemaDeGestion(baseDeDatos, interaccionUsuario)
    sistema.iniciar()
}