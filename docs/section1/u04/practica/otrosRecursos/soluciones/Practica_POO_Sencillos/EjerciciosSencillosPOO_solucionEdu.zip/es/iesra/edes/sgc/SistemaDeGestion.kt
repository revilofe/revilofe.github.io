package es.iesra.edes.sgc

// Clase SistemaDeGestion que actúa como controladora
class SistemaDeGestion(
    private val baseDeDatos: BaseDeDatosClientes,
    private val interaccionUsuario: InteraccionUsuario
) {

    fun iniciar() {
        var opcion: Int
        do {
            opcion = interaccionUsuario.pedirOpcion()
            when (opcion) {
                1 -> accionAgregarCliente()
                2 -> accionEliminarCliente()
                3 -> accionMostrarCliente()
                4 -> accionListarTodosLosClientes()
                5 -> accionListarClientesPreferentes()
                6 -> interaccionUsuario.mostrarMensaje("¡Hasta luego!")
                else -> interaccionUsuario.mostrarMensaje("Opción no válida. Intenta de nuevo.")
            }
        } while (opcion != 6)
    }

    private fun accionAgregarCliente() {
        val cliente = interaccionUsuario.solicitarDatosCliente()
        if (baseDeDatos.agregarCliente(cliente)) {
            interaccionUsuario.mostrarMensaje("Cliente añadido correctamente.")
        } else {
            interaccionUsuario.mostrarMensaje("Ya existe un cliente con ese NIF.")
        }
    }

    private fun accionEliminarCliente() {
        val nif = interaccionUsuario.solicitarDato("Introduce el NIF del cliente a eliminar: ")
        if (baseDeDatos.eliminarCliente(nif)) {
            interaccionUsuario.mostrarMensaje("Cliente eliminado correctamente.")
        } else {
            interaccionUsuario.mostrarMensaje("No se encontró un cliente con ese NIF.")
        }
    }

    private fun accionMostrarCliente() {
        val nif = interaccionUsuario.solicitarDato("Introduce el NIF del cliente a mostrar: ")
        val cliente = baseDeDatos.buscarCliente(nif)
        if (cliente != null)
            interaccionUsuario.mostrarCliente(cliente)
        else
            interaccionUsuario.mostrarMensaje("No se encontró un cliente con ese NIF.")

    }

    private fun accionListarTodosLosClientes() {
        val clientes = baseDeDatos.listarTodosLosClientes()
        interaccionUsuario.mostrarListaClientes(clientes, "Lista de todos los clientes")
    }

    private fun accionListarClientesPreferentes() {
        val clientesPreferentes = baseDeDatos.listarClientesPreferentes()
        interaccionUsuario.mostrarListaClientes(clientesPreferentes, "Lista de clientes preferentes")
    }
}