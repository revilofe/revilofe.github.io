package es.iesra.prog.basicos.Libro

class Libro(val titulo: String, val autor: String, val numPaginas: Int = 100, var leido: Boolean = false){

    init{
        if (titulo.isEmpty() || autor.isEmpty()){
            throw Exception("El título y el autor no pueden estar vacíos")
        }

        if (numPaginas <= 0 || numPaginas > 5000){
            throw Exception("El número de páginas debe ser un valor positivo no superior a 5000")
        }
    }
    //Propiedades

    //Constructor
    constructor(titulo: String, autor: String) : this(titulo, autor, 100, false)

    //Métodos
    override fun toString(): String {
        //"Libro: [titulo] por [autor], Páginas: [numPaginas], Leído: [Sí/No]"
        return "Libro: ${titulo} por ${autor}, Páginas: ${numPaginas}, Leído: ${if (leido) "Sí" else "No"}"
    }
}