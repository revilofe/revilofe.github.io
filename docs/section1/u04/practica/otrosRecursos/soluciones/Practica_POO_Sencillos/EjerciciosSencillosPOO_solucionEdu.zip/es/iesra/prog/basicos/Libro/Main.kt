package es.iesra.prog.basicos.Libro

/**
 * Ejercicio 3: Clase Libro
 * Crea una clase Libro con las propiedades:
 *
 * [x] titulo (de tipo String).
 * [x] autor (de tipo String).
 * [x] numPaginas (de tipo Int).
 * [x] leido (de tipo Boolean, inicializado en false).
 *
 *
 * La clase debe:
 *
 * [x] Sobrescribir el método toString para mostrar: "Libro: [titulo] por [autor], Páginas: [numPaginas], Leído: [Sí/No]".
 * [x] Incluir un constructor secundario que inicialice numPaginas y leido con valores predeterminados.
 * A tener en cuenta:
 *
 * [x] las propiedades titulo, autor y numPaginas serán propiedades inmutables.
 * [x] titulo y autor no pueden ser cadenas vacías.
 * [x] numPaginas debe ser un valor positivo, no superior a 5000.
 * [x] Por defecto un libro tiene 100 páginas si no se especifica al inicializarlo.
 * [x] En el programa principal:
 *
 * Crea dos libros, marca uno como leído e imprime el valor de cada libro.
 * Crea un libro con titulo vacío que muestre el mensaje de error correspondiente (acuérdate de capturar las excepciones).
 * Diseño:
 * Aquí tienes el diagrama UML para la clase Libro que implementa las especificaciones del ejercicio:
 *
 * Libro.png
 *
 * Contenido del Diagrama:
 * Clase: Libro
 * Atributos:
 * titulo: String: El título del libro.
 * autor: String: El autor del libro.
 * numPaginas: Int = 100: Número de páginas con valor predeterminado de 100.
 * leido: Boolean = false: Indica si el libro ha sido leído, inicializado en false.
 * Métodos:
 * Libro(titulo: String, autor: String, numPaginas: Int = 100, leido: Boolean = false): Constructor que permite inicializar el libro.
 * toString(): String: Sobrescribe el método toString para proporcionar una descripción del libro.
 * Características del diseño:
 * Las propiedades son privadas (-) para mantener su encapsulación.
 * Se permite un constructor secundario que inicializa valores predeterminados para numPaginas y leido.
 */

fun main(){

    val libro1 = Libro("El Quijote", "Cervantes", 1000, leido = true)
    val libro2 = Libro("El Señor de los Anillos", "J.R.R. Tolkien")
    println(libro1)
    println(libro2)

    try{
        val libro3 = Libro("", "Autor")
    }catch (e: Exception){
        println(e.message)
    }




}

