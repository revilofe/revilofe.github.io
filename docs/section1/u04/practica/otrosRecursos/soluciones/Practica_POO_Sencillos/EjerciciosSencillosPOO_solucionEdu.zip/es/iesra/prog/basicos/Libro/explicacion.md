### Explicación detallada del **Ejercicio 3: Clase `Libro`**

Este ejercicio consiste en implementar una clase que modele un libro, con restricciones específicas para sus propiedades y características adicionales como la validación de valores, un constructor secundario, y una representación textual mediante el método `toString`.

---

### **Requisitos del ejercicio**

1. Crear una clase `Libro` con las propiedades:
    - `titulo` (tipo `String`): El título del libro, no debe ser una cadena vacía.
    - `autor` (tipo `String`): El autor del libro, tampoco debe ser una cadena vacía.
    - `numPaginas` (tipo `Int`): Número de páginas, debe ser un valor positivo y no superior a 5000.
    - `leido` (tipo `Boolean`): Indica si el libro ha sido leído, inicializado por defecto en `false`.

2. Implementar:
    - Validaciones en el bloque `init` para las restricciones de las propiedades.
    - Un constructor secundario que permita inicializar solo `titulo` y `autor`, asignando valores predeterminados a las otras propiedades.
    - Sobrescribir el método `toString` para devolver una representación detallada del libro.

3. En el programa principal:
    - Crear dos libros, marcar uno como leído e imprimir su representación.
    - Intentar crear un libro con título vacío y capturar la excepción generada.

---

### **Código con comentarios**

```kotlin
package es.iesra.edes.basicos.libro

/**
 * Clase Libro
 * Representa un libro con título, autor, número de páginas y un estado de lectura.
 *
 * @property titulo El título del libro (inmutable).
 * @property autor El autor del libro (inmutable).
 * @property numPaginas El número de páginas, debe ser un valor positivo y no superior a 5000.
 * @property leido Indica si el libro ha sido leído, inicializado en `false` por defecto.
 */
class Libro(val titulo: String, val autor: String, val numPaginas: Int = 100, var leido: Boolean = false) {

    /**
     * Bloque init: Valida las restricciones de las propiedades al inicializar un objeto de tipo Libro.
     */
    init {
        if (titulo.isEmpty() || autor.isEmpty()) {
            throw Exception("El título y el autor no pueden estar vacíos")
        }
        if (numPaginas <= 0 || numPaginas > 5000) {
            throw Exception("El número de páginas debe ser un valor positivo y no superior a 5000")
        }
    }

    /**
     * Constructor secundario:
     * Permite crear un libro con valores predeterminados para `numPaginas` y `leido`.
     */
    constructor(titulo: String, autor: String) : this(titulo, autor, 100, false)

    /**
     * Sobrescribe el método `toString` para devolver una representación detallada del libro.
     * @return Cadena con el formato: "Libro: [titulo] por [autor], Páginas: [numPaginas], Leído: [Sí/No]"
     */
    override fun toString(): String {
        return "Libro: $titulo por $autor, Páginas: $numPaginas, Leído: ${if (leido) "Sí" else "No"}"
    }
}

// Programa principal para probar la clase Libro
fun main() {
    try {
        // Crear libros con diferentes configuraciones
        val libro1 = Libro("El Quijote", "Cervantes", 1000, leido = true)
        val libro2 = Libro("El Señor de los Anillos", "J.R.R. Tolkien")

        // Mostrar detalles de los libros
        println(libro1)
        println(libro2)

        // Intentar crear un libro con título vacío (generará una excepción)
        val libro3 = Libro("", "Autor")
    } catch (e: Exception) {
        // Capturar y mostrar el mensaje de error generado
        println("Error: ${e.message}")
    }
}
```

---

### **Explicación del diseño**

#### **Clase `Libro`**

1. **Propiedades:**
    - `titulo` y `autor`:
        - Declaradas como `val` porque son inmutables, es decir, no pueden cambiar después de ser inicializadas. Esto asegura que los datos fundamentales del libro permanezcan constantes.
    - `numPaginas`:
        - Declarada como `val` con un valor predeterminado de 100 en el constructor primario, cumpliendo con las especificaciones del ejercicio.
    - `leido`:
        - Declarada como `var` porque el estado de lectura puede cambiar después de la creación del objeto.

2. **Validaciones en `init`:**
    - `titulo` y `autor` no pueden ser cadenas vacías, lo que se valida al inicializar un objeto.
    - `numPaginas` debe ser positivo y no exceder 5000. Si no se cumple, se lanza una excepción con un mensaje claro.

3. **Constructor secundario:**
    - Ofrece una forma más simple de inicializar un libro sin necesidad de especificar `numPaginas` y `leido`. Internamente, llama al constructor primario con valores predeterminados.

4. **Sobrescritura de `toString`:**
    - Proporciona una representación detallada del libro que incluye su estado de lectura (`Leído: Sí/No`).

---

#### **Función principal**

1. **Creación de objetos:**
    - Se crean dos libros con diferentes configuraciones (uno leído y otro no leído).
    - Uno de los libros utiliza el constructor secundario.

2. **Manejo de excepciones:**
    - Intenta crear un libro con un título vacío, lo que genera una excepción. La excepción es capturada en el bloque `try-catch`, mostrando un mensaje de error al usuario.

---

### **Ejemplo de ejecución**

#### Entrada:
```text
1. Crear un libro con título "El Quijote", autor "Cervantes", 1000 páginas, marcado como leído.
2. Crear un libro con título "El Señor de los Anillos", autor "J.R.R. Tolkien", usando valores predeterminados.
3. Intentar crear un libro con título vacío.
```

#### Salida:
```text
Libro: El Quijote por Cervantes, Páginas: 1000, Leído: Sí
Libro: El Señor de los Anillos por J.R.R. Tolkien, Páginas: 100, Leído: No
Error: El título y el autor no pueden estar vacíos
```

---

### **Decisiones clave de diseño**

1. **Inmutabilidad de propiedades clave:**
    - Se eligieron `titulo`, `autor` y `numPaginas` como `val` para mantener la integridad de los datos del libro.

2. **Validaciones explícitas:**
    - Las restricciones sobre las propiedades se verifican en el bloque `init`, lo que garantiza que cualquier instancia de `Libro` creada sea válida.

3. **Constructor secundario:**
    - Permite inicializaciones rápidas sin tener que repetir valores predeterminados.

4. **Sobrescritura de `toString`:**
    - Ofrece una representación clara y estructurada del objeto al imprimirlo.

---

### **Posibles mejoras**

1. **Validaciones más robustas:**
    - Agregar validaciones para que los valores de `titulo` y `autor` no contengan solo espacios en blanco.

2. **Métodos adicionales:**
    - Incluir métodos como `marcarLeido()` para cambiar el estado de `leido` de manera más intuitiva.

3. **Control de excepciones más específico:**
    - Usar excepciones más especializadas como `IllegalArgumentException` para diferenciar errores específicos.

---

Este diseño cumple con los requisitos del ejercicio y es extensible, permitiendo añadir nuevas funcionalidades si se necesitan.