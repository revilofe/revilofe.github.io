package es.iesra.prog.basicos.cuentabancaria

class CuentaBancaria(val titular: String){
    // Atributos
    var saldo: Double = 0.0
        private set


    // Métodos
    fun ingresar(cantidad: Double){
        if (cantidad <= 0){
            throw Exception("No se puede ingresar cantidades negativas o 0")
        }

        saldo += cantidad
    }

    fun retirar(cantidad: Double){
        if (cantidad > saldo){
            throw Exception("No se puede retirar más dinero del que hay en la cuenta")
        }

        saldo -= cantidad
    }

}