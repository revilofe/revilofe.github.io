/**
 * Ejercicio 1: Clase Cuenta Bancaria.
 * [x]Crea una clase CuentaBancaria con las propiedades:
 *
 * [x]titular (de tipo String).
 * [x]saldo (de tipo Double).
 * La clase debe tener:
 *
 * [x]Un constructor que inicialice el titular, y el saldo en 0 por defecto.
 * Métodos para:
 * [x]Ingresar dinero (ingresar).
 * [x]Retirar dinero (retirar). [x]Este método debe lanzar una excepción si se intenta retirar más dinero del que hay en la cuenta.
 * A tener en cuenta:
 *
 * [x] El saldo no podrá ser modificado directamente desde fuera de la clase. Solo será posible su cambio mediante los métodos ingresar y retirar.
 * [x] Los métodos ingresar y retirar debe mostrar un mensaje con el saldo final después de la operación.
 * [x]No será posible retirar más dinero del saldo actual, [x]ni ingresar cantidades negativas o 0. Deberá generar una excepción si ocurre esta situación.
 * En el programa principal:
 *
 * [x]Crea una cuenta bancaria con un titular.
 * [x]Realiza un ingreso de 100.0 y un retiro de 50.0.
 * [x]Intenta realizar un retiro que supere el saldo y captura la excepción.
 * Diseño:
 * Aquí tienes el diagrama UML para la clase CuentaBancaria que implementa las especificaciones del ejercicio:
 *
 * CuentaBancaria
 *
 * Contenido del Diagrama:
 * Clase: CuentaBancaria
 * Atributos:
 * titular: String: El nombre del titular.
 * saldo: Double = 0.0: El saldo de la cuenta, inicializado a 0.
 * Métodos:
 * CuentaBancaria(titular: String): Constructor que inicializa la cuenta con un titular y saldo en 0.
 * ingresar(cantidad: Double): void: Método para ingresar dinero.
 * retirar(cantidad: Double): void: Método para retirar dinero.
 * Características del diseño:
 * Los atributos son privados (-) para asegurar el encapsulamiento.
 * Los métodos públicos (+) controlan las operaciones sobre el saldo.
 *
 */

package es.iesra.prog.basicos.cuentabancaria

fun main(){
    val unaJerezana = "Paola Perez Ponce"
    val cuenta = CuentaBancaria(unaJerezana)

    try{
        println("Introduce la cantidad a ingresar: ")
        var montante = readln().toDouble()
        cuenta.ingresar(montante)
        println("Saldo después de ingresar ${montante}: ${cuenta.saldo}")

        println("Introduce la cantidad a retirar: ")
        montante = readln().toDouble()
        cuenta.retirar(montante)
        println("Saldo después de retirar ${montante}: ${cuenta.saldo}")

        println("Introduce la cantidad a retirar: ")
        montante = readln().toDouble()
        cuenta.retirar(montante)
        println("Saldo después de retirar ${montante}: ${cuenta.saldo}")
    }
    catch (e: Exception){
        println("Error: ${e.message}")
    }


}


