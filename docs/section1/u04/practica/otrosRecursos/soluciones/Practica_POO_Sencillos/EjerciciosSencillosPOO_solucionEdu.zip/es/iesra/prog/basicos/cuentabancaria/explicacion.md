### Explicación detallada del **Ejercicio 1: Clase `CuentaBancaria`**

A continuación, se detalla la implementación de la clase `CuentaBancaria`, explicando cada decisión de diseño, así como los comentarios en el código para facilitar su comprensión.

---

#### **Requisitos del ejercicio**

1. Crear una clase `CuentaBancaria` con las propiedades:
    - `titular` (de tipo `String`): El nombre del titular de la cuenta.
    - `saldo` (de tipo `Double`): Representa el dinero disponible en la cuenta.
2. Implementar:
    - Constructor que inicialice `titular` y asigne `saldo = 0.0` por defecto.
    - Métodos para:
        - Ingresar dinero (`ingresar`).
        - Retirar dinero (`retirar`), validando que no se pueda retirar más del saldo disponible.
    - Encapsular `saldo` para que no sea modificable directamente desde fuera de la clase.
    - Validaciones en los métodos:
        - No se puede ingresar cantidades negativas o cero.
        - No se puede retirar más dinero del disponible.

---

### Código con comentarios

```kotlin
package es.iesra.edes.basicos.cuentabancaria

/**
 * Clase CuentaBancaria
 * Representa una cuenta bancaria con un titular y saldo asociado.
 *
 * @property titular Nombre del titular de la cuenta.
 * @property saldo Dinero disponible en la cuenta, inicializado a 0.0 y privado para evitar accesos directos.
 */
class CuentaBancaria(val titular: String) {

    // Propiedad `saldo` con encapsulación para proteger el acceso directo
    var saldo: Double = 0.0
        private set // Se define un `private set` para evitar que sea modificada desde fuera de la clase.

    /**
     * Método para ingresar dinero a la cuenta.
     * @param cantidad La cantidad a ingresar, debe ser mayor que 0.
     * @throws Exception Si la cantidad es menor o igual a 0.
     */
    fun ingresar(cantidad: Double) {
        // Validar que la cantidad sea mayor que 0
        if (cantidad <= 0) {
            throw Exception("No se puede ingresar cantidades negativas o 0")
        }

        // Actualizar el saldo sumando la cantidad ingresada
        saldo += cantidad
    }

    /**
     * Método para retirar dinero de la cuenta.
     * @param cantidad La cantidad a retirar, debe ser menor o igual al saldo disponible.
     * @throws Exception Si la cantidad excede el saldo disponible.
     */
    fun retirar(cantidad: Double) {
        // Validar que la cantidad no exceda el saldo disponible
        if (cantidad > saldo) {
            throw Exception("No se puede retirar más dinero del que hay en la cuenta")
        }

        // Actualizar el saldo restando la cantidad retirada
        saldo -= cantidad
    }
}

fun main() {
    // Creación de una cuenta bancaria para un titular
    val cuenta = es.iesra.prog.basicos.cuentabancaria.CuentaBancaria("Paola Perez Ponce")

    try {
        // Ingreso de una cantidad válida
        println("Introduce la cantidad a ingresar: ")
        var montante = readln().toDouble()
        cuenta.ingresar(montante)
        println("Saldo después de ingresar ${montante}: ${cuenta.saldo}")

        // Retiro de una cantidad válida
        println("Introduce la cantidad a retirar: ")
        montante = readln().toDouble()
        cuenta.retirar(montante)
        println("Saldo después de retirar ${montante}: ${cuenta.saldo}")

        // Intento de retirar más de lo disponible (genera excepción)
        println("Introduce la cantidad a retirar: ")
        montante = readln().toDouble()
        cuenta.retirar(montante)
        println("Saldo después de retirar ${montante}: ${cuenta.saldo}")
    } catch (e: Exception) {
        // Captura y muestra cualquier error durante las operaciones
        println("Error: ${e.message}")
    }
}
```

---

### Explicación línea a línea

#### **Clase `CuentaBancaria`**

1. **Propiedades de la clase:**
    - `titular`: Es una propiedad inmutable (`val`) porque el titular no debería cambiar una vez creada la cuenta.
    - `saldo`: Se declara como `var` porque su valor cambia durante el uso de la cuenta, pero con un `private set` para asegurar que solo los métodos internos puedan modificar su valor. Esto refuerza la encapsulación.

2. **Método `ingresar`:**
    - Valida que la cantidad sea mayor que 0 para evitar entradas inválidas.
    - Si la validación pasa, suma la cantidad al saldo actual.
    - Lanzar una excepción en caso de valor inválido asegura que el programa no permita operaciones erróneas.

3. **Método `retirar`:**
    - Comprueba que la cantidad a retirar no exceda el saldo actual, protegiendo la cuenta de sobregiros.
    - Si la cantidad es válida, la resta del saldo.
    - Lanzar una excepción si la cantidad excede el saldo protege la integridad de los datos.

---

#### **Función `main`**

1. **Creación de la cuenta:**
    - Se inicializa una instancia de `CuentaBancaria` con el titular `Paola Perez Ponce`.

2. **Interacción con el usuario:**
    - Solicita al usuario que introduzca cantidades para ingreso y retiro.
    - Realiza las operaciones correspondientes llamando a los métodos `ingresar` y `retirar`.

3. **Manejo de excepciones:**
    - Las excepciones se capturan en un bloque `try-catch` para mostrar mensajes de error al usuario sin interrumpir el programa.

---

### Ejemplo de ejecución

#### Entrada:
```
Introduce la cantidad a ingresar:
100
Introduce la cantidad a retirar:
50
Introduce la cantidad a retirar:
200
```

#### Salida:
```
Saldo después de ingresar 100.0: 100.0
Saldo después de retirar 50.0: 50.0
Error: No se puede retirar más dinero del que hay en la cuenta
```

---

### Decisiones clave de diseño

1. **Encapsulación:**
    - `saldo` está protegido con un `private set` para garantizar que las únicas formas de modificarlo sean a través de los métodos `ingresar` y `retirar`.

2. **Validaciones:**
    - Garantizan que solo se permitan operaciones válidas (evitando ingresos negativos o retiros superiores al saldo).

3. **Uso de excepciones:**
    - Proporcionan un manejo robusto de errores, previniendo estados inválidos en la cuenta bancaria.

4. **Interacción con el usuario:**
    - La función `main` está diseñada para simular un flujo básico de operaciones, mostrando el impacto de cada acción sobre el saldo.

Este enfoque asegura un diseño claro, seguro y funcional, cumpliendo con los principios de programación orientada a objetos.