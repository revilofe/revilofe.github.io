package es.iesra.prog.basicos.estudiante

/**
 * Ejercicio 4: Clase Estudiante
 * Crea una clase Estudiante con las propiedades:
 *
 * [x] nombre
 * [x] nota
 * La clase debe:
 *
 * [x] Modificar el setter de nota para asegurarse de que esté en el rango 0-10.
 * [x] Sobrescribir el método toString para mostrar: "Estudiante: [nombre], Nota: [nota]".
 * A tener en cuenta:
 *
 * [x] El nombre del estudiante no se podrá modificar una vez inicializado un objeto de tipo Estudiante.
 * [x] La propiedad nombre no puede ser tampoco visible desde fuera de la clase Estudiante.
 * En el programa principal:
 *
 * [x] Crea varios estudiantes, intenta asignarles notas fuera del rango y muestra sus detalles.
 * Diseño:
 * Aquí tienes el diagrama UML para la clase Estudiante, implementando las especificaciones del ejercicio 4:
 *
 * Estudiante
 *
 * Contenido del Diagrama:
 * Clase: Estudiante
 * Atributos:
 *
 * nombre: String: Nombre del estudiante, inmutable y no visible externamente.
 * nota: Double: Nota del estudiante, ajustable dentro del rango 0-10 mediante un método.
 * Métodos:
 *
 * Estudiante(nombre: String): Constructor que inicializa el nombre del estudiante.
 * setNota(nota: Double): void: Establece la nota validando que esté entre 0 y 10.
 * toString(): String: Devuelve una descripción en el formato: Estudiante: [nombre], Nota: [nota].
 * Características del diseño:
 * Las propiedades son privadas (-) para mantener su encapsulación. Sin embargo existen los métodos getter y setter, adaptados para la propiedad nota según las especificaciones.
 * El constructor estaría disponible para inicializar el nombre del estudiante.
 *
 */


fun main(){
    var estudiante1 = Estudiante("Pepe")
    var estudiante2 = Estudiante("Juan")
    try{

        estudiante1.nota = 5.0
        println("La nota de $estudiante1")
        estudiante2.nota = -3.0
        println("La nota de $estudiante1")

    }catch (e: Exception){
        println(e.message)
    }

}

