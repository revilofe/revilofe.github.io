### Explicación detallada del **Ejercicio 4: Clase `Estudiante`**

El objetivo de este ejercicio es implementar una clase que modele un estudiante, con propiedades específicas, validaciones para asegurar la consistencia de los datos y una representación textual que facilite la comprensión de su estado.

---

### **Requisitos del ejercicio**

1. Crear una clase `Estudiante` con las propiedades:
    - `nombre` (tipo `String`): El nombre del estudiante, que no puede ser modificado ni visible desde fuera de la clase.
    - `nota` (tipo `Double`): La calificación del estudiante, que debe estar en el rango de 0 a 10.

2. Implementar:
    - Un constructor que permita inicializar el nombre del estudiante.
    - Un `setter` para `nota` que valide que el valor esté entre 0 y 10.
    - Sobrescribir el método `toString` para devolver una representación detallada del estudiante.

3. En el programa principal:
    - Crear varios estudiantes.
    - Intentar asignarles notas fuera del rango permitido y capturar las excepciones generadas.
    - Mostrar los detalles de los estudiantes.

---

### **Código con comentarios**

```kotlin
package es.iesra.edes.basicos.estudiante

/**
 * Clase Estudiante
 * Representa a un estudiante con un nombre inmutable y una nota validada.
 *
 * @property nombre El nombre del estudiante, inmutable y no visible desde fuera de la clase.
 * @property nota La nota del estudiante, debe estar entre 0 y 10.
 */
class Estudiante(private val nombre: String) {

    // Propiedad mutable para almacenar la nota del estudiante, con validación en el setter
    var nota: Double = 0.0
        set(value) {
            // Validación para garantizar que la nota esté entre 0 y 10
            if (value < 0 || value > 10) {
                throw Exception("La nota debe estar entre 0 y 10")
            }
            field = value // Se usa el campo de respaldo para asignar el valor
        }

    /**
     * Sobrescribe el método `toString` para devolver una representación detallada del estudiante.
     * @return Una cadena con el formato: "Estudiante: [nombre], Nota: [nota]"
     */
    override fun toString(): String {
        return "Estudiante: $nombre, Nota: $nota"
    }
}

// Programa principal para probar la clase Estudiante
fun main() {
    // Crear instancias de Estudiante
    val estudiante1 = es.iesra.prog.basicos.estudiante.Estudiante("Pepe")
    val estudiante2 = es.iesra.prog.basicos.estudiante.Estudiante("Juan")

    try {
        // Asignar una nota válida
        estudiante1.nota = 8.5
        println(estudiante1)

        // Intentar asignar una nota inválida (genera una excepción)
        estudiante2.nota = 12.0
        println(estudiante2)
    } catch (e: Exception) {
        // Capturar y mostrar el mensaje de error generado
        println("Error: ${e.message}")
    }

    // Mostrar los detalles finales de los estudiantes
    println(estudiante1)
    println(estudiante2)
}
```

---

### **Explicación del diseño**

#### **Clase `Estudiante`**

1. **Propiedad `nombre`:**
    - Declarada como `private val` para que sea inmutable y no visible desde fuera de la clase. Esto asegura que el nombre del estudiante no pueda ser modificado después de la creación del objeto.
    - Se inicializa mediante el constructor, asegurando que todos los estudiantes tengan un nombre válido al ser creados.

2. **Propiedad `nota`:**
    - Declarada como `var` porque su valor puede cambiar con el tiempo.
    - Se incluye un `setter` personalizado que valida que la nota esté en el rango de 0 a 10. Si no se cumple esta condición, se lanza una excepción para evitar valores inconsistentes.

3. **Sobrescritura de `toString`:**
    - Proporciona una representación textual detallada del estudiante, que incluye su nombre y nota. Esto es útil para depuración y para mostrar información al usuario.

---

#### **Función principal**

1. **Creación de objetos:**
    - Se crean dos estudiantes (`estudiante1` y `estudiante2`) con nombres diferentes.

2. **Asignación de notas:**
    - Se asigna una nota válida al primer estudiante.
    - Se intenta asignar una nota inválida (fuera del rango permitido) al segundo estudiante. Esto genera una excepción.

3. **Manejo de excepciones:**
    - La excepción generada al asignar una nota inválida se captura en un bloque `try-catch`, mostrando un mensaje de error al usuario en lugar de interrumpir el programa.

---

### **Ejemplo de ejecución**

#### Entrada:
```text
1. Crear un estudiante llamado "Pepe".
2. Crear un estudiante llamado "Juan".
3. Asignar la nota 8.5 a "Pepe".
4. Intentar asignar la nota 12.0 a "Juan".
```

#### Salida:
```text
Estudiante: Pepe, Nota: 8.5
Error: La nota debe estar entre 0 y 10
Estudiante: Pepe, Nota: 8.5
Estudiante: Juan, Nota: 0.0
```

---

### **Decisiones clave de diseño**

1. **Encapsulación del nombre:**
    - El nombre se declara como `private` para evitar accesos directos. Esto protege la consistencia del objeto y cumple con los principios de encapsulación.

2. **Validación de notas:**
    - El uso de un `setter` personalizado asegura que cualquier intento de asignar valores inválidos a la nota sea detectado inmediatamente.

3. **Uso de excepciones:**
    - Las excepciones permiten manejar errores de forma controlada, evitando que valores incorrectos corrompan el estado del objeto.

4. **Representación clara:**
    - El método `toString` facilita la visualización del estado actual del objeto, lo que resulta útil en contextos de depuración o interacción con el usuario.

---

### **Posibles mejoras**

1. **Validación del nombre:**
    - Agregar una validación para evitar que el nombre sea una cadena vacía o que contenga solo espacios en blanco.

2. **Métodos adicionales:**
    - Implementar un método `aprobar` que permita determinar si el estudiante aprobó (nota mayor o igual a 5).

3. **Excepciones específicas:**
    - Usar excepciones más detalladas como `IllegalArgumentException` para diferenciar tipos de errores.

4. **Control de visibilidad:**
    - Incluir un método `getNombre()` si se requiere acceder al nombre desde fuera de la clase.

---

Este diseño cumple con los requisitos del ejercicio, asegurando un manejo seguro de los datos y facilitando futuras extensiones.