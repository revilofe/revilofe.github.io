package es.iesra.prog.basicos.producto


fun main(){
    val producto1 = Producto("Leche", 1.0, 10)
    val producto2 = Producto("Pan", 0.5, 20)
    val producto3 = Producto("Huevos", 2.0, 5)

    println(producto1)
    println(producto2)
    println(producto3)

    producto1.vender(5)
    producto2.reabastecer(10)
    producto3.vender(3)

    println(producto1)
    println(producto2)
    println(producto3)
}