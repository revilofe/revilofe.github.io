package es.iesra.prog.basicos.producto

/**
 * Ejercicio 5: Clase Producto
 * Crea una clase Producto con las propiedades:
 *
 * [x] nombre
 * [x] precio
 * [x] stock
 * La clase debe:
 *
 * [x] Utilizar un bloque init para asegurarse de que el precio y el stock sean positivos.
 * [x] Sobrescribir el método toString para mostrar: "Producto: [nombre], Precio: [precio]€, Stock: [stock]".
 * [x] Métodos vender y reabastecer, que actualizarán el stock. Realizar los controles que veáis adecuados.
 * [x] Las propiedades precio y stock no pueden ser modificadas directamente desde fuera de la clase Producto.
 * En el programa principal:
 *
 * Crea varios productos, usa sus métodos y muestra sus detalles.
 * Diseño:
 * Aquí tienes el diagrama UML para la clase Producto, implementando las especificaciones del ejercicio 5:
 *
 * Producto
 *
 * Contenido del Diagrama:
 * Clase: Atributos
 * Atributos:
 * nombre: String: Nombre del producto.
 * precio: Double: Precio del producto, validado para ser positivo mediante un bloque init.
 * stock: Int: Cantidad de stock disponible, validada para ser positiva mediante un bloque init.
 * Métodos:
 * Producto(nombre: String, precio: Double, stock: Int): Constructor que inicializa el producto y valida los atributos.
 * vender(cantidad: Int): void: Reduce el stock si hay suficiente cantidad disponible.
 * reabastecer(cantidad: Int): void: Incrementa el stock del producto.
 * toString(): String: Devuelve una descripción en el formato: Producto: [nombre], Precio: [precio]€, Stock: [stock].
 * Características del diseño:
 * Las propiedades son privadas (-) para mantener su encapsulación. Sin embargo, se han definido métodos para operar con ellas.
 * El constructor inicializa el producto y valida los atributos.
 */


class Producto(val nombre: String, val precio: Double, stock: Int) {

    var stock = stock
        private set

    init {
        if(precio < 0.0 ){
            throw IllegalArgumentException("El precio debe ser positivos")
        }
        if(stock < 0){
            throw IllegalArgumentException("El stock debe ser positivos")
        }
    }

    fun vender(cantidad: Int){
        if(cantidad > stock){
            throw IllegalArgumentException("No hay suficiente stock")
        }
        stock -= cantidad
    }

    fun reabastecer(cantidad: Int){
        if(cantidad < 0){
            throw IllegalArgumentException("La cantidad de stock a reabastecer debe ser positiva")
        }
        stock += cantidad
    }

    override fun toString(): String {
        return "Producto: $nombre, Precio: $precio€, Stock: $stock"
    }

}