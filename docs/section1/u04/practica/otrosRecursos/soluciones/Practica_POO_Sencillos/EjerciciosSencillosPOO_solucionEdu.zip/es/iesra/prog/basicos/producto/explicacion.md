### Explicación detallada del **Ejercicio 5: Clase `Producto`**

Este ejercicio se enfoca en modelar un producto con propiedades como nombre, precio, y stock, asegurando que sus valores sean válidos y que solo puedan modificarse mediante métodos específicos.

---

### **Requisitos del ejercicio**

1. Crear una clase `Producto` con las propiedades:
    - `nombre` (tipo `String`): El nombre del producto.
    - `precio` (tipo `Double`): El precio del producto, debe ser positivo.
    - `stock` (tipo `Int`): Cantidad disponible, debe ser positivo.

2. Implementar:
    - Validaciones en un bloque `init` para asegurar que `precio` y `stock` sean valores válidos.
    - Métodos:
        - `vender(cantidad: Int)`: Disminuye el stock si hay suficiente disponible.
        - `reabastecer(cantidad: Int)`: Aumenta el stock con la cantidad especificada, validando que sea positiva.
    - Sobrescribir el método `toString` para devolver una representación detallada del producto.

3. En el programa principal:
    - Crear varios productos, usar sus métodos y mostrar sus detalles.

---

### **Código con comentarios**

```kotlin
package es.iesra.edes.basicos.producto

/**
 * Clase Producto
 * Representa un producto con nombre, precio y stock, validando los valores y controlando sus modificaciones.
 *
 * @property nombre Nombre del producto (inmutable).
 * @property precio Precio del producto (inmutable y validado para ser positivo).
 * @property stock Cantidad disponible del producto, mutable pero con restricciones para ser positivo.
 */
class Producto(val nombre: String, val precio: Double, stock: Int) {

    // Propiedad mutable para el stock, con un setter privado para proteger la modificación directa
    var stock = stock
        private set

    /**
     * Bloque init: Valida que el precio y el stock iniciales sean positivos.
     */
    init {
        if (precio <= 0.0) {
            throw IllegalArgumentException("El precio debe ser positivo")
        }
        if (stock < 0) {
            throw IllegalArgumentException("El stock debe ser positivo")
        }
    }

    /**
     * Método para vender una cantidad del producto.
     * @param cantidad La cantidad a vender, debe ser menor o igual al stock disponible.
     * @throws IllegalArgumentException Si la cantidad es mayor al stock actual.
     */
    fun vender(cantidad: Int) {
        if (cantidad > stock) {
            throw IllegalArgumentException("No hay suficiente stock para realizar la venta")
        }
        stock -= cantidad
    }

    /**
     * Método para reabastecer el producto.
     * @param cantidad La cantidad a añadir al stock, debe ser positiva.
     * @throws IllegalArgumentException Si la cantidad es negativa.
     */
    fun reabastecer(cantidad: Int) {
        if (cantidad <= 0) {
            throw IllegalArgumentException("La cantidad de reabastecimiento debe ser positiva")
        }
        stock += cantidad
    }

    /**
     * Sobrescribe el método `toString` para devolver una representación detallada del producto.
     * @return Una cadena con el formato: "Producto: [nombre], Precio: [precio]€, Stock: [stock]"
     */
    override fun toString(): String {
        return "Producto: $nombre, Precio: $precio€, Stock: $stock"
    }
}

// Programa principal para probar la clase Producto
fun main() {
    try {
        // Crear productos con diferentes configuraciones
        val producto1 = es.iesra.prog.basicos.producto.Producto("Leche", 1.2, 10)
        val producto2 = es.iesra.prog.basicos.producto.Producto("Pan", 0.8, 5)
        val producto3 = es.iesra.prog.basicos.producto.Producto("Huevos", 2.5, 12)

        // Mostrar detalles iniciales
        println(producto1)
        println(producto2)
        println(producto3)

        // Usar métodos de venta y reabastecimiento
        producto1.vender(3)
        producto2.reabastecer(10)
        producto3.vender(15) // Esto generará una excepción

        // Mostrar detalles finales
        println(producto1)
        println(producto2)
        println(producto3)
    } catch (e: Exception) {
        // Capturar y mostrar cualquier error
        println("Error: ${e.message}")
    }
}
```

---

### **Explicación del diseño**

#### **Clase `Producto`**

1. **Propiedades:**
    - `nombre`: Declarada como `val` para que sea inmutable, ya que el nombre de un producto no debería cambiar después de su creación.
    - `precio`: También es `val` porque no se espera que el precio cambie una vez definido. Se valida en el bloque `init` para asegurar que sea positivo.
    - `stock`: Declarado como `var` porque su valor cambia mediante los métodos `vender` y `reabastecer`. Tiene un `private set` para evitar modificaciones externas directas.

2. **Validaciones en el bloque `init`:**
    - Verifica que:
        - El precio sea mayor que 0.
        - El stock inicial sea mayor o igual a 0.
    - Si no se cumple alguna de estas condiciones, se lanza una excepción con un mensaje claro.

3. **Método `vender`:**
    - Disminuye el stock según la cantidad especificada.
    - Incluye una validación para evitar que se venda más de lo disponible, lanzando una excepción si esto ocurre.

4. **Método `reabastecer`:**
    - Aumenta el stock en la cantidad especificada.
    - Valida que la cantidad sea positiva para evitar inconsistencias.

5. **Sobrescritura de `toString`:**
    - Proporciona una representación clara y detallada del producto, mostrando su nombre, precio, y stock actual.

---

#### **Función principal**

1. **Creación de productos:**
    - Se instancian varios productos con valores iniciales diferentes.
    - Las validaciones en el constructor aseguran que solo se creen productos válidos.

2. **Operaciones sobre los productos:**
    - Se llaman los métodos `vender` y `reabastecer` para modificar el stock.
    - En un caso, se intenta vender más de lo disponible, lo que genera una excepción.

3. **Manejo de excepciones:**
    - Se captura cualquier excepción generada durante las operaciones, mostrando mensajes de error al usuario.

---

### **Ejemplo de ejecución**

#### Entrada:
```text
1. Crear tres productos:
   - Leche: Precio 1.2€, Stock 10.
   - Pan: Precio 0.8€, Stock 5.
   - Huevos: Precio 2.5€, Stock 12.
2. Vender 3 unidades de Leche.
3. Reabastecer 10 unidades de Pan.
4. Intentar vender 15 unidades de Huevos (más de lo disponible).
```

#### Salida:
```text
Producto: Leche, Precio: 1.2€, Stock: 10
Producto: Pan, Precio: 0.8€, Stock: 5
Producto: Huevos, Precio: 2.5€, Stock: 12
Error: No hay suficiente stock para realizar la venta
Producto: Leche, Precio: 1.2€, Stock: 7
Producto: Pan, Precio: 0.8€, Stock: 15
Producto: Huevos, Precio: 2.5€, Stock: 12
```

---

### **Decisiones clave de diseño**

1. **Inmutabilidad de propiedades clave:**
    - Se eligieron `nombre` y `precio` como `val` para evitar cambios accidentales después de la creación del objeto.

2. **Encapsulación de `stock`:**
    - El `private set` asegura que solo los métodos `vender` y `reabastecer` puedan modificar el stock, garantizando que los cambios sean controlados.

3. **Validaciones claras:**
    - Las excepciones lanzadas en el bloque `init` y los métodos aseguran que los valores de las propiedades siempre sean válidos.

4. **Representación clara:**
    - La sobrescritura de `toString` proporciona una forma rápida de verificar el estado actual del producto.

---

### **Posibles mejoras**

1. **Soporte para precios dinámicos:**
    - Incluir un método para cambiar el precio de un producto, con validación.

2. **Manejo de errores específico:**
    - Usar excepciones más detalladas como `IllegalArgumentException` o `IllegalStateException`.

3. **Historial de operaciones:**
    - Registrar un historial de ventas y reabastecimientos para cada producto.

4. **Automatización de reabastecimiento:**
    - Agregar un sistema de alerta cuando el stock sea bajo, sugiriendo reabastecimiento.

---

Este diseño cumple con los requisitos del ejercicio, garantizando un manejo seguro de los datos y proporcionando flexibilidad para futuras extensiones.