package es.iesra.prog.basicos.vehiculo

/**
 * Clase Vehiculo: Representa un vehículo con marca, modelo y kilometraje.
 * @property marca
 * @property modelo
 * @property kilometraje
 * @constructor Crea un vehículo con marca y modelo.
 *
 *
 */
class Vehiculo(val marca: String, val modelo: String){
    var kilometraje: Double= 0.0

    /**
     * Obtiene una descripción del vehículo.
     * @return Descripción del vehículo.
     */
    fun obtenerDetelles(): String {
        return "Vehiculo(marca='$marca', modelo='$modelo', kilometraje=$kilometraje)"
    }

    /**
     * Registra un viaje aumentando el kilometraje.
     * @param km Cantidad de kilómetros recorridos.
     */
    fun registrarViaje(km: Double){
        kilometraje+= km
    }
}