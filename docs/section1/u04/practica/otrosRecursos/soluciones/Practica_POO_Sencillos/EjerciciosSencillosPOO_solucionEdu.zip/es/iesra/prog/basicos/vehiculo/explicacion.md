### Explicación detallada del **Ejercicio 2: Clase `Vehiculo`**

El ejercicio consiste en crear una clase que represente un vehículo, permitiendo registrar viajes (aumentar el kilometraje) y mostrar los detalles del vehículo de forma estructurada.

---

### **Requisitos del ejercicio**

1. Crear una clase `Vehiculo` con las propiedades:
    - `marca`: Representa la marca del vehículo.
    - `modelo`: Representa el modelo del vehículo.
    - `kilometraje`: Representa la distancia total recorrida por el vehículo.

2. Implementar:
    - Un método para registrar un viaje que incremente el kilometraje.
    - Un método (o sobrescribir `toString`) para obtener los detalles del vehículo en formato texto.

3. En el programa principal:
    - Crear un vehículo con una marca y modelo.
    - Registrar un viaje de 100 km.
    - Mostrar los detalles del vehículo antes y después de registrar el viaje.

---

### **Código con comentarios**

```kotlin
package es.iesra.edes.basicos.vehiculo

/**
 * Clase Vehiculo
 * Representa un vehículo con las propiedades marca, modelo y kilometraje.
 * 
 * @property marca La marca del vehículo (inmutable).
 * @property modelo El modelo del vehículo (inmutable).
 * @property kilometraje La distancia total recorrida por el vehículo (mutable).
 */
class Vehiculo(val marca: String, val modelo: String) {

    // Propiedad mutable para almacenar el kilometraje total del vehículo
    var kilometraje: Double = 0.0

    /**
     * Método para obtener una descripción del vehículo.
     * @return Una cadena con los detalles de la marca, modelo y kilometraje.
     */
    fun obtenerDetelles(): String {
        return "Vehiculo(marca='$marca', modelo='$modelo', kilometraje=$kilometraje km)"
    }

    /**
     * Método para registrar un viaje y actualizar el kilometraje.
     * @param km La cantidad de kilómetros recorridos en el viaje.
     */
    fun registrarViaje(km: Double) {
        // Validación para evitar valores negativos o inválidos en los viajes
        if (km < 0) {
            throw IllegalArgumentException("Los kilómetros recorridos no pueden ser negativos")
        }

        // Incrementar el kilometraje con el valor proporcionado
        kilometraje += km
    }
}

// Función principal que prueba la clase Vehiculo
fun main() {
    // Creación de un objeto de tipo Vehiculo
    val coche = es.iesra.progs.basicos.vehiculo.Vehiculo("Toyota", "GT86")

    // Mostrar los detalles iniciales del vehículo
    println(coche.obtenerDetelles())

    // Registrar un viaje de 100 km
    coche.registrarViaje(100.0)

    // Registrar otro viaje de 200 km
    coche.registrarViaje(200.0)

    // Mostrar los detalles finales del vehículo
    println(coche.obtenerDetelles())
}
```

---

### **Explicación del diseño**

#### **Clase `Vehiculo`**

1. **Propiedades `marca` y `modelo`:**
    - Declaradas como `val` porque son atributos que no deberían cambiar durante la vida útil del objeto. Esto asegura la inmutabilidad y refuerza el diseño basado en principios de encapsulación.
    - La inicialización de estas propiedades se realiza a través del constructor primario.

2. **Propiedad `kilometraje`:**
    - Declarada como `var` porque su valor debe cambiar al registrar viajes.
    - Inicializada a `0.0`, indicando que el vehículo no ha recorrido ninguna distancia al momento de su creación.

3. **Método `obtenerDetelles`:**
    - Devuelve una descripción del vehículo que incluye la marca, modelo y kilometraje actual.
    - Este método permite representar de forma clara el estado actual del vehículo.

4. **Método `registrarViaje`:**
    - Permite aumentar el kilometraje del vehículo al registrar un nuevo viaje.
    - Incluye una validación que lanza una excepción si el parámetro `km` es negativo. Esto asegura que los datos del vehículo sean consistentes y evita errores lógicos.

---

#### **Función principal**

1. **Creación de un vehículo:**
    - Se instancia un objeto de tipo `Vehiculo` con valores para las propiedades `marca` y `modelo`.

2. **Operaciones con el vehículo:**
    - Se llama a `obtenerDetelles` para mostrar el estado inicial del vehículo.
    - Se registran dos viajes (de 100 km y 200 km respectivamente) usando el método `registrarViaje`.
    - Después de cada viaje, se llama nuevamente a `obtenerDetelles` para reflejar el cambio en el kilometraje.

---

### **Decisiones clave de diseño**

1. **Inmutabilidad de `marca` y `modelo`:**
    - Estas propiedades son constantes (`val`) porque no se espera que cambien una vez asignadas. Esto sigue el principio de diseño que busca evitar cambios accidentales en datos importantes.

2. **Mutable `kilometraje`:**
    - Se eligió como `var` porque representa un valor que cambiará con el tiempo, siguiendo el propósito de registrar viajes.

3. **Validación en `registrarViaje`:**
    - El control de que `km >= 0` asegura que no se registren valores inválidos. Es preferible lanzar una excepción en estos casos para evitar que el vehículo tenga datos incorrectos.

4. **Uso de métodos específicos (`obtenerDetelles`):**
    - En lugar de sobrescribir `toString`, se prefirió implementar un método dedicado para obtener detalles. Esto permite personalizar el formato de salida sin interferir con el método heredado.

---

### **Ejemplo de ejecución**

#### Entrada:
```text
1. Crear un vehículo con marca "Toyota" y modelo "GT86".
2. Mostrar detalles iniciales.
3. Registrar un viaje de 100 km.
4. Registrar un viaje de 200 km.
5. Mostrar detalles finales.
```

#### Salida:
```text
Vehiculo(marca='Toyota', modelo='GT86', kilometraje=0.0 km)
Vehiculo(marca='Toyota', modelo='GT86', kilometraje=100.0 km)
Vehiculo(marca='Toyota', modelo='GT86', kilometraje=300.0 km)
```

---

### **Posibles mejoras**

1. **Agregar más validaciones:**
    - Validar que el modelo y la marca no sean cadenas vacías en el constructor.

2. **Sobrescribir `toString`:**
    - Aunque no es obligatorio, sobrescribir `toString` podría simplificar la obtención de detalles cuando se use el objeto en contextos que imprimen directamente el estado del objeto.

3. **Manejo de errores en la función principal:**
    - En la función `main`, se podrían capturar las excepciones generadas al intentar registrar un viaje con kilómetros negativos, mostrando un mensaje más amigable al usuario.

---

Este diseño de la clase `Vehiculo` es sencillo pero robusto, cumpliendo con los requisitos del ejercicio y dejando margen para extensiones futuras.