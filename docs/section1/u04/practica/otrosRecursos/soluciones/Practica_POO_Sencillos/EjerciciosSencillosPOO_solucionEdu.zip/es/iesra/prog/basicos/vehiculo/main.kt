package es.iesra.prog.basicos.vehiculo

/**
 *x Ejercicio 2: Clase Vehículo
 *x Crea una clase Vehiculo con las propiedades:
 *
 *x marca.
 *x modelo.
 *x kilometraje.
 *x La clase debe tener:
 *
 *x Métodos para registrar un viaje que aumente el kilometraje.
 *x Un método detalles que devuelva una descripción del vehículo o modificar el método toString.
 *x En el programa principal:
 *
 *x Crea un vehículo, registra un viaje de 100 km y muestra sus detalles.
 */


fun main(){
    val coche= Vehiculo("Toyota", "GT86")
    println(coche.obtenerDetelles())
    coche.registrarViaje(100.0)
    coche.registrarViaje(200.0)
    println(coche.obtenerDetelles())
}

